import pygame
import os
import time
pygame.init()

m=1 #질량 
k=1 #용수철 상수
c=0.5 #마찰 상수 
x=1 #물체의 초기 위치
v=0 #물체의 초기 속도

dt=0.1 #0.1초 간격으로 계산
maxt=20 #20초까지 계산

def F(x,v): #F(x,v)=합력, -kx=탄성력, -cv=마찰력
    return -k*x-c*v

#파일&이미지 경로
now_path=os.path.dirname(__file__) 
heart_path=os.path.join(now_path,"하트.png")
box_path=os.path.join(now_path,"제목 없음.png")
hand_path=os.path.join(now_path,"손.png")

#이미지 로드
Screen=pygame.display.set_mode([800,600])
box=pygame.image.load(box_path)
heart=pygame.image.load(heart_path)
hand=pygame.image.load(hand_path)
clock=pygame.time.Clock()

#잡아당기는 상황 연출
x_=0 #잡아당길때 하트 위치
while x_<x:
    Screen.fill((255,255,255))
    spring_x=10 #스프링 위치
    spring_box=pygame.font.SysFont("Bold",30)
    bar=spring_box.render("|",True,(255,0,0)) #하트 처음 위치 표시 바 
    while spring_x<x_*200+400: #하트까지 스프링 연결
        spring=spring_box.render("-",True,(0,0,0))
        Screen.blit(spring,[spring_x,500])
        spring_x=spring_x+30

    Screen.blit(bar,[412,530])
    Screen.blit(heart,[x_*200+400,500])
    Screen.blit(box,[10,490])
    Screen.blit(hand,[x_*200+430,350])
    pygame.display.update()
    
    if x_==0: #처음에 0.5초 기다렸다가 잡아당김
        time.sleep(0.5)
        
    x_=x_+0.02
    clock.tick(70)
time.sleep(1)


t=0
while t<maxt:
    #계산
    a=F(x,v)/m
    x=x+v*dt
    v=v+a*dt
    t=t+dt

    Screen.fill((255,255,255))

    #스프링 연결
    spring_x=10 
    while spring_x<x*200+400:
        spring_box=pygame.font.SysFont("Bold",30)
        spring=spring_box.render("-",True,(0,0,0))
        Screen.blit(spring,[spring_x,500])
        spring_x=spring_x+30

    #스크린에 띄우기
    Screen.blit(box,[10,490])
    Screen.blit(heart,[x*200+400,500])
    Screen.blit(bar,[412,530])
    pygame.display.update()
    clock.tick(70)
    
